If you couldn't monitorize the .obj or .stl files,
click the View on top of folder then click Preview Pane.
Lastly, click the folders what you want to monitorize it.

Important!
When you change the name of .obj folders, you can't view.

.obj Files
If you want to modify the .obj folders, you should open on Blender.